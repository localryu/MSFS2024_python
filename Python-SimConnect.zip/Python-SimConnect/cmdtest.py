﻿import ctypes
import os

import time
from SimConnect import *


os.add_dll_directory(r"C:\Users\aam\Desktop\msfstutorial\Python-SimConnect")
dll = ctypes.CDLL(r"C:\Users\aam\Desktop\msfstutorial\Python-SimConnect\MSFSResetDLL.dll")

dll.ResetAircraftPosition.argtypes = [ctypes.c_double, ctypes.c_double, ctypes.c_double]

latitude = 37.4602
longitude = 126.4407
altitude = 20.0

dll.ResetAircraftPosition(latitude, longitude, altitude)


# SimConnect 연결
sm = SimConnect()
#aq = AircraftRequests(sm, _time=2000)  # 2초마다 데이터 업데이트
# 이벤트 객체 생성
ae = AircraftEvents(sm)

try:
    #ae.Miscellaneous_Systems.SIM_RESET
    ae.Engine.ENGINE_AUTO_SHUTDOWN()
    time.sleep(0.1)
    dll.ResetAircraftPosition(latitude, longitude, altitude)
    ae.Miscellaneous_Systems.SIM_RESET
    time.sleep(1)
    # 시동걸기
    #ae.Engine.TOGGLE_STARTER1()
    #time.sleep(0.5)
    #ae.Miscellaneous_Systems.PARKING_BRAKES()
    #time.sleep(0.5)
    #ae.Engine.THROTTLE1_FULL()
    #time.sleep(0.5)
    # 엔진 1의 쓰로틀을 50% (값은 0~16383 사이)
    #value = int(16383 * 0.5)
    # ae.Engine.THROTTLE1_SET(value)

except KeyboardInterrupt:
    print("end")

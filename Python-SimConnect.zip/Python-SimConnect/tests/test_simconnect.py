from SimConnect import *

from unittest import TestCase

import logging

LOGGER = logging.getLogger(__name__)

class TestSimple(TestCase):
	def test_init_simconnect(self):
		self.assertTrue(True)

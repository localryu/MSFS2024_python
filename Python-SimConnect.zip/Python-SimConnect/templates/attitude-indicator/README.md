https://dannyedwards.gitlab.io/attitude-indicator/
https://github.com/saasmath/attitude-indicator
